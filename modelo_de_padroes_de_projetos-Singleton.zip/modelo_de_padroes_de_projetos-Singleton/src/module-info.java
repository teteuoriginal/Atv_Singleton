module projetoSingleton {
}